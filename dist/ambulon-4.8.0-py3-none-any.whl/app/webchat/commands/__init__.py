"""Commands package for webchat.
"""
