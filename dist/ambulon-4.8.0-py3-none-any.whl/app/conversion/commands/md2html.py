"""
Command to convert Markdown files to HTML (simple conversion, no diagrams).

This module provides basic Markdown to HTML conversion WITHOUT diagram support.
For conversion with diagram support (PlantUML, Mermaid, Graphviz), use:
    ambulon md2html-diagrams document.md
"""

import sys
import argparse
import re
import logging
from pathlib import Path
from typing import Optional

from app.core.logging_config import setup_logging
from app.core.output_paths import format_output_path

logger = logging.getLogger(__name__)


def process_markdown_to_html_simple(
    markdown_path: str,
    output_path: Optional[str] = None,
    verbose: bool = False,
    standalone: bool = True,
    add_toc_backlinks: bool = False,
) -> int:
    """
    Convert a Markdown file to HTML (simple conversion, no diagrams).

    This is the basic Markdown to HTML converter that does NOT process
    PlantUML, Mermaid, or Graphviz diagrams. For diagram support, use
    the 'md2html-diagrams' command from the diagrams module.

    Args:
        markdown_path: Path to the input Markdown file
        output_path: Optional output HTML path. If None, uses same name with .html extension
        verbose: Print verbose output
        standalone: Generate standalone HTML with CSS and full page structure
        add_toc_backlinks: Add back-to-TOC links (↑) after each heading

    Returns:
        Exit code (0 for success, 1 for error)
    """
    md_path = Path(markdown_path).resolve()

    # Check if markdown file exists
    if not md_path.exists():
        logger.error(f"Markdown file '{markdown_path}' does not exist.")
        return 1

    if not md_path.is_file():
        logger.error(f"'{markdown_path}' is not a file.")
        return 1

    # Determine output path
    if output_path is None:
        output_path = md_path.parent / (md_path.stem + ".html")
    else:
        output_path = Path(output_path)

    output_path = output_path.resolve()

    logger.info(f"Processing: {md_path}")
    logger.info(f"Output: {output_path}")

    try:
        # Read markdown content with encoding detection
        content = _read_file_with_encoding(md_path, verbose)
        if content is None:
            return 1

        # Convert markdown to HTML
        html_content = markdown_to_html_basic(content, add_toc_backlinks=add_toc_backlinks)

        # Wrap in full HTML if standalone
        if standalone:
            html_content = wrap_html_document(html_content, md_path.stem)

        # Write output
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        rel_path = format_output_path(output_path)
        logger.info("✓ Conversion md2html reussie !")
        logger.info("Fichier produit : %s", rel_path)

        return 0

    except Exception as e:
        logger.error(f"Failed to convert markdown: {e}", exc_info=verbose)
        return 1


def _read_file_with_encoding(file_path: Path, verbose: bool = False) -> Optional[str]:
    """Read file trying multiple encodings."""
    encodings_to_try = ['utf-8', 'cp1252', 'latin-1', 'iso-8859-1']

    for encoding in encodings_to_try:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            if verbose and encoding != 'utf-8':
                logger.info(f"File was read with {encoding} encoding (not UTF-8)")
            return content
        except UnicodeDecodeError:
            continue

    logger.error(f"Could not decode file with any supported encoding: {', '.join(encodings_to_try)}")
    return None


def markdown_to_html_basic(content: str, add_toc_backlinks: bool = False) -> str:
    """
    Basic markdown to HTML conversion for common elements.
    """
    # Clean anchor tags with empty href attributes
    content = re.sub(r'<a\s+id="([^"]+)"\s+href=""\s*></a>', r'<a id="\1"></a>', content)

    # Convert markdown links BEFORE protecting HTML
    def convert_md_link(match):
        text = match.group(1)
        url = match.group(2)
        if url.endswith('.md'):
            url = url[:-3] + '.html'
        return f'<a href="{url}">{text}</a>'

    content = re.sub(r'\[([^\]]+)\]\(([^\)]+)\)', convert_md_link, content)

    # Protect HTML tags
    html_tags = {}
    def save_html_tag(match):
        placeholder = f'___HTML_TAG_{len(html_tags)}___'
        html_tags[placeholder] = match.group(0)
        return placeholder

    content = re.sub(r'<a\s+id="[^"]+"\s*></a>', save_html_tag, content)
    content = re.sub(r'<a\s+href="[^"]+">.*?</a>', save_html_tag, content)
    content = re.sub(r'<details[^>]*>.*?</details>', save_html_tag, content, flags=re.DOTALL)
    content = re.sub(r'</?(?:summary|div)[^>]*>', save_html_tag, content)

    # Protect code blocks
    code_block_pattern = r'(`{3,})([^\n`]*)\n(.*?)\1(?:\n|$)'
    code_blocks = {}
    def save_code_block(match):
        lang = match.group(2).strip() or ''
        code = match.group(3)
        placeholder = f'___CODE_BLOCK_{len(code_blocks)}___'
        code_escaped = code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        code_blocks[placeholder] = f'<pre><code class="language-{lang}">{code_escaped}</code></pre>'
        return placeholder

    content = re.sub(code_block_pattern, save_code_block, content, flags=re.DOTALL)

    # Convert tables
    table_pattern = r'(\|.+\|[\r\n]+\|[\s\-:|]+\|[\r\n]+(?:\|.+\|[\r\n]+)*)'
    tables = re.findall(table_pattern, content, re.MULTILINE)
    table_placeholders = {}

    for i, table in enumerate(tables):
        placeholder = f'___TABLE_PLACEHOLDER_{i}___'
        table_placeholders[placeholder] = convert_markdown_table(table)
        content = content.replace(table, placeholder, 1)

    # Generate TOC if [TOC] marker present
    toc_html = ''
    if '[TOC]' in content:
        toc_html = generate_toc(content)
        content = content.replace('[TOC]', '___TOC_PLACEHOLDER___')

    # Convert headings
    def convert_heading(match, level):
        text = match.group(1).strip()
        id_match = re.search(r'\s*\{#([a-z0-9\-_]+)\}\s*$', text, re.IGNORECASE)
        if id_match:
            heading_id = id_match.group(1)
            text = text[:id_match.start()].strip()
        else:
            heading_id = re.sub(r'[^\w\s-]', '', text.lower())
            heading_id = re.sub(r'[\s_]+', '-', heading_id).strip('-')

        if add_toc_backlinks:
            return f'<h{level} id="{heading_id}">{text} <a href="#table-of-contents" class="back-to-toc" title="Retour à la table des matières">↑</a></h{level}>'
        else:
            return f'<h{level} id="{heading_id}">{text}</h{level}>'

    content = re.sub(r'^# (.+)$', lambda m: convert_heading(m, 1), content, flags=re.MULTILINE)
    content = re.sub(r'^## (.+)$', lambda m: convert_heading(m, 2), content, flags=re.MULTILINE)
    content = re.sub(r'^### (.+)$', lambda m: convert_heading(m, 3), content, flags=re.MULTILINE)
    content = re.sub(r'^#### (.+)$', lambda m: convert_heading(m, 4), content, flags=re.MULTILINE)

    if toc_html:
        content = content.replace('___TOC_PLACEHOLDER___', toc_html)

    # Convert inline formatting
    content = re.sub(r'`([^`]+)`', r'<code>\1</code>', content)
    content = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', content)
    content = re.sub(r'\*(.+?)\*', r'<em>\1</em>', content)

    # Convert blockquotes and lists
    lines = content.split('\n')
    result_lines = []
    in_blockquote = False
    blockquote_lines = []
    in_list = False

    for line in lines:
        if line.startswith('> '):
            if not in_blockquote:
                if in_list:
                    result_lines.append('</ul>')
                    in_list = False
                in_blockquote = True
            blockquote_lines.append(line[2:])
        elif re.match(r'^[-*+] ', line):
            if in_blockquote:
                result_lines.append('<blockquote>')
                result_lines.extend(blockquote_lines)
                result_lines.append('</blockquote>')
                blockquote_lines = []
                in_blockquote = False
            if not in_list:
                result_lines.append('<ul>')
                in_list = True
            item = re.sub(r'^[-*+] ', '', line)
            result_lines.append(f'<li>{item}</li>')
        else:
            if in_blockquote:
                result_lines.append('<blockquote>')
                result_lines.extend(blockquote_lines)
                result_lines.append('</blockquote>')
                blockquote_lines = []
                in_blockquote = False
            if in_list:
                result_lines.append('</ul>')
                in_list = False
            result_lines.append(line)

    if in_blockquote:
        result_lines.append('<blockquote>')
        result_lines.extend(blockquote_lines)
        result_lines.append('</blockquote>')
    if in_list:
        result_lines.append('</ul>')

    content = '\n'.join(result_lines)

    # Convert horizontal rules
    content = re.sub(r'^---$', r'<hr>', content, flags=re.MULTILINE)

    # Convert paragraphs
    paragraphs = content.split('\n\n')
    new_paragraphs = []

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue

        # Skip if already HTML block
        if para.startswith('___'):
            new_paragraphs.append(para)
            continue
        if re.match(r'^<(table|ul|ol|blockquote|pre|h[1-6]|nav|div|figure)', para):
            new_paragraphs.append(para)
            continue
        if para.startswith('</'):
            new_paragraphs.append(para)
            continue

        # Replace single newlines with <br>
        para = para.replace('\n', '<br>\n')
        new_paragraphs.append(f'<p>{para}</p>')

    content = '\n\n'.join(new_paragraphs)

    # Restore protected blocks
    for placeholder, code_html in code_blocks.items():
        content = content.replace(placeholder, code_html)

    for placeholder, table_html in table_placeholders.items():
        content = content.replace(placeholder, table_html)

    for placeholder, tag in html_tags.items():
        content = content.replace(placeholder, tag)

    return content


def convert_markdown_table(table_text: str) -> str:
    """Convert a markdown table to HTML table."""
    lines = [line.strip() for line in table_text.strip().split('\n') if line.strip()]

    if len(lines) < 2:
        return table_text

    header_cells = [cell.strip() for cell in lines[0].split('|')[1:-1]]
    data_rows = []
    for line in lines[2:]:
        cells = [cell.strip() for cell in line.split('|')[1:-1]]
        if cells:
            data_rows.append(cells)

    html = '<table>\n<thead>\n<tr>\n'
    for cell in header_cells:
        html += f'<th>{convert_inline_markdown(cell)}</th>\n'
    html += '</tr>\n</thead>\n<tbody>\n'

    for row in data_rows:
        html += '<tr>\n'
        for cell in row:
            html += f'<td>{convert_inline_markdown(cell)}</td>\n'
        html += '</tr>\n'

    html += '</tbody>\n</table>'
    return html


def convert_inline_markdown(text: str) -> str:
    """Convert inline markdown (bold, italic, code) to HTML."""
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
    text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', text)
    return text


def generate_toc(content: str) -> str:
    """Generate a Table of Contents from markdown headers."""
    toc_items = []
    header_pattern = r'^(#{1,4})\s+(.+?)(?:\s*\{#([a-z0-9\-_]+)\})?\s*$'

    for match in re.finditer(header_pattern, content, re.MULTILINE | re.IGNORECASE):
        level = len(match.group(1))
        text = match.group(2).strip()
        explicit_id = match.group(3)

        if explicit_id:
            heading_id = explicit_id
        else:
            heading_id = re.sub(r'[^\w\s-]', '', text.lower())
            heading_id = re.sub(r'[\s_]+', '-', heading_id).strip('-')

        toc_items.append({'level': level, 'text': text, 'id': heading_id})

    if not toc_items:
        return ''

    toc_html = ['<nav class="table-of-contents" id="table-of-contents">']
    toc_html.append('<h2>Table des matières</h2>')
    toc_html.append('<ul>')

    for item in toc_items:
        indent = '  ' * (item['level'] - 1)
        toc_html.append(f'{indent}<li><a href="#{item["id"]}">{item["text"]}</a></li>')

    toc_html.append('</ul>')
    toc_html.append('</nav>')

    return '\n'.join(toc_html)


def wrap_html_document(content: str, title: str) -> str:
    """Wrap HTML content in a full document with CSS."""
    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            color: #333;
        }}
        pre {{
            background: #f4f4f4;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }}
        code {{
            background: #f4f4f4;
            padding: 2px 5px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
            margin: 20px 0;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }}
        th {{
            background: #f4f4f4;
        }}
        .back-to-toc {{
            text-decoration: none;
            font-size: 0.8em;
            margin-left: 10px;
        }}
        blockquote {{
            border-left: 4px solid #ddd;
            margin: 0;
            padding-left: 16px;
            color: #666;
        }}
        hr {{
            border: none;
            border-top: 1px solid #ddd;
            margin: 20px 0;
        }}
    </style>
</head>
<body>
{content}
</body>
</html>"""


def main():
    """Entry point for md2html command."""
    parser = argparse.ArgumentParser(
        description="""
        Convert Markdown to HTML (simple conversion, NO diagram support).
        
        This command converts Markdown files to HTML WITHOUT processing
        PlantUML, Mermaid, or Graphviz diagrams.
        
        For conversion WITH diagram support, use:
            ambulon md2html-diagrams document.md
        """,
        epilog="""
        Examples:
          ambulon md2html document.md
          ambulon md2html document.md -o output.html --toc-backlinks
          
        For diagram support:
          ambulon md2html-diagrams document.md
        """
    )

    parser.add_argument("input", type=str, help="Input Markdown file")
    parser.add_argument("-o", "--output", type=str, help="Output HTML file (default: <input>.html)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    parser.add_argument("--no-standalone", action="store_true", help="Output HTML fragment only (no CSS)")
    parser.add_argument("--toc-backlinks", action="store_true", help="Add back-to-TOC links after headings")

    args = parser.parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    setup_logging(level=log_level, log_file_prefix="md2html")
    logger.info("[START] Starting md2html conversion (simple, no diagrams).")

    return process_markdown_to_html_simple(
        markdown_path=args.input,
        output_path=args.output,
        verbose=args.verbose,
        standalone=not args.no_standalone,
        add_toc_backlinks=args.toc_backlinks,
    )


if __name__ == '__main__':
    sys.exit(main())
