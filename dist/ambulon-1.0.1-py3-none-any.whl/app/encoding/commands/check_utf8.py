"""
CLI command to check UTF-8 encoding of Markdown files for Ambulon.
Utilizes the core checking logic from app.encoding.core.checker.
Handles CLI arguments, configuration loading, and logging.
"""

import typer
import logging
import os
from pathlib import Path
from typing import List, Optional

from app.core.config_loader import load_config as load_app_config
from app.core.logging_config import setup_logging
from ..core.checker import check_markdown_files

logger = logging.getLogger(__name__)

app = typer.Typer()

DEFAULT_CONFIG = {
    'encoding': {
        'check_utf8': {
            'min_confidence': 0.7,
        }
    }
}

@app.command(
    help="""
    Checks UTF-8 encoding of Markdown files.

    Configuration Hierarchy (from highest to lowest priority):
    1. Command-line arguments
    2. YAML configuration file (`--config`, e.g., `config/encoding.yaml`)
    3. Environment variables (e.g., CHECK_UTF8_MIN_CONFIDENCE)
    4. Default values
    """
)
def main(
    patterns: List[str] = typer.Argument(..., help="Glob pattern(s) for Markdown files (e.g., 'si/**/*.md', 'docs/*.md')."),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Not used for this command, but kept for compatibility."),
    config_path: Optional[Path] = typer.Option(None, "--config", "-c", help="Path to a YAML configuration file (e.g., config/encoding.yaml)."),
    
    # Global options
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose logging."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress most output messages."),

    # Check specific options
    min_confidence: Optional[float] = typer.Option(None, "--min-confidence", help="Minimum confidence for encoding detection (0.0 to 1.0). Overrides config/env."),
):
    """
    CLI for checking UTF-8 encoding of Markdown files.
    """
    # Configure logging
    log_level = logging.DEBUG if verbose else (logging.WARNING if quiet else logging.INFO)
    setup_logging(level=log_level, log_file_prefix="check_utf8")
    logger.info("[START] Starting check-utf8 module.")
    logger.debug(f"CLI arguments: {typer.Context.get_current().params}")

    # Load configuration
    config = load_app_config(str(config_path) if config_path else None, DEFAULT_CONFIG)
    check_config = config['encoding']['check_utf8']

    # Apply CLI overrides (highest priority) and resolve config
    final_min_confidence = min_confidence if min_confidence is not None else check_config.get('min_confidence', DEFAULT_CONFIG['encoding']['check_utf8']['min_confidence'])

    # Execute checking logic
    results = check_markdown_files(
        patterns=patterns,
        min_confidence=final_min_confidence
    )

    has_issue = False
    for res in results:
        encoding = res.get('encoding') or 'inconnu'
        confidence = res.get('confidence', 0.0)
        error = res.get('error')
        path_str = Path(res['path']).relative_to(Path.cwd()) if 'path' in res else 'Unknown Path'

        if error:
            logger.error(f"❌ {path_str} → Erreur: {error}")
            has_issue = True
        elif encoding and encoding.upper() not in ("UTF-8", "UTF8", "ASCII"):
            logger.warning(f"⚠️  {path_str} → Encodage non UTF-8: {encoding} (confiance: {confidence:.2%})")
            has_issue = True
        elif confidence < final_min_confidence:
            logger.warning(f"⚠️  {path_str} → Faible confiance: {encoding} (confiance: {confidence:.2%})")
            has_issue = True
        else:
            logger.info(f"✅ {path_str} → Encodage: {encoding} (confiance: {confidence:.2%})")
    
    if has_issue:
        logger.error("\nCompleted with issues.")
        raise typer.Exit(code=1)
    else:
        logger.info("\nAll specified Markdown files passed encoding checks.")
        raise typer.Exit(code=0)

if __name__ == '__main__':
    app()